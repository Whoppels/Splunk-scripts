Splunk Add-on for Cisco WSA
Copyright (C) 2021 Splunk Inc. All Rights Reserved.

For documentation, see: http://docs.splunk.com/Documentation/AddOns/latest/CiscoWSA
