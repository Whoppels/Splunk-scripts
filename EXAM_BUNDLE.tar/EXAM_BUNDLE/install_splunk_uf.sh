#!/bin/bash
echo
echo '###################################################'
echo '#                                                 #'
echo '# Splunk Universal Forwarder 8.1.2 auto-installer #'
echo '# for RHEL/CentOS 7 x64.                          #'
echo '# Last updated 02/28/2021.                        #'
echo '#                                                 #'
echo '###################################################'
echo

## Grab hostname variable ##
splunkHost=`hostname`

## Set Script Variables splunkUsername/splunkGroup ##
echo "Enter the username for the splunk OS user account (default: splunk)"
read splunkUsername
echo "Enter the group for the splunk OS user account (default: splunk)"
read splunkGroup
splunkUsername="${splunkUsername:=splunk}"
splunkGroup="${splunkGroup:=splunk}"
#echo "Creating user:$splunkUsername group:$splunkGroup"
echo
#groupadd $splunkGroup
#useradd -m $splunkUsername -g $splunkGroup
mkdir -p /opt/splunkforwarder/
usermod -d /opt/splunkforwarder $splunkUsername
## END Set Script Variables splunkUsername/splunkGroup ##

## Install WGET ##
#echo "Installing wget"
#echo
#sudo yum --enablerepo=prod install wget-1.14-18.el7_6.1.x86_64 -y
## END Install WGET ##

## Download Splunk UF Installer ##
cd /tmp
echo "Download Splunk Forwarder installer"
echo
wget -O splunkforwarder-8.1.2-545206cc9f70-Linux-x86_64.tgz 'https://www.splunk.com/bin/splunk/DownloadActivityServlet?architecture=x86_64&platform=linux&version=8.1.2&product=universalforwarder&filename=splunkforwarder-8.1.2-545206cc9f70-Linux-x86_64.tgz&wget=true'
echo "Install /tmp/splunkforwarder-8.tgz to /opt/splunkforwarder/"
echo
## END Download Splunk UF Installer ##

## Install Splunk UF ##
tar -xzvf /tmp/splunkforwarder-8*.tgz -C /opt
rm -rf splunkforwarder-8.tgz
chown -R $splunkUsername:$splunkGroup /opt/splunkforwarder
## END Install Splunk UF ##

## First Start of Splunk ##
echo "Start Splunk"
echo
runuser -l $splunkUsername -c "/opt/splunkforwarder/bin/splunk start --accept-license --answer-yes"
echo "Enable Splunk to start on boot"
echo
/opt/splunkforwarder/bin/splunk enable boot-start -user $splunkUsername
runuser -l $splunkUsername -c '/opt/splunkforwarder/bin/splunk stop'
## END First Start of Splunk ##

#  Check to make sure default host value is set, if not, set it now
if [[ -f /opt/splunkforwarder/etc/system/local/inputs.conf ]]
        then
                break
        else
                echo "Setting default host value for Splunk..."
                echo "[default]" > /opt/splunkforwarder/etc/system/local/inputs.conf
                echo "host = $splunkHost" >> /opt/splunkforwarder/etc/system/local/inputs.conf
                cat /opt/splunkforwarder/etc/system/local/inputs.conf
        fi

## Preconfigure Deployment Client Configuration ##
#echo "Set Deployment Server"
#echo
#mkdir -p /opt/splunkforwarder/etc/apps/arch_deploymentclient_base
#mkdir -p /opt/splunkforwarder/etc/apps/arch_deploymentclient_base/local
#echo "[target-broker:deploymentServer]" > /opt/splunkforwarder/etc/apps/_faa_deploymentclient_base/local/deploymentclient.conf
#echo "targetUri = 10.1.1.201:8089" >> /opt/splunkforwarder/etc/apps/_faa_deploymentclient_base/local/deploymentclient.conf
## END Preconfigure Deployment Client Configuration ##

## Preconfigure Deployment Client clientName ##
echo "Set Deployment Client clientName"
echo "[deployment-client]" > /opt/splunkforwarder/etc/system/local/deploymentclient.conf
echo "clientName = splunk-uf" >> /opt/splunkforwarder/etc/system/local/deploymentclient.conf
## END Preconfigure Deployment Client clientName ##

## Final config/start up ##
chown -R $splunkUsername:$splunkGroup /opt/splunkforwarder
chown root:$splunkGroup /opt/splunkforwarder/etc/splunk-launch.conf
chmod 644 /opt/splunkforwarder/etc/splunk-launch.conf
echo "Starting Splunk one more time"
echo
runuser -l $splunkUsername -c '/opt/splunkforwarder/bin/splunk start'
echo
## END Final config/start up ##

