Splunk Add-on for Unix and Linux version 8.2.0
Copyright (C) 2020 Splunk Inc. All Rights Reserved.

For documentation, see: http://docs.splunk.com/Documentation/UnixAddOn/latest
